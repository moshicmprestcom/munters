import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BooksComponent } from './components/books/books.component';
import { BookListComponent } from './components/book-list/book-list.component';
import { BookDetailsComponent } from './components/book-details/book-details.component';
import { MaterialModule } from '../material.module';
import { BooksService } from './services/books.service';
import { FormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
@NgModule({
  declarations: [BooksComponent, BookListComponent, BookDetailsComponent],
  exports: [
    BooksComponent
  ],
  providers: [
    BooksService
  ],
  imports: [
    CommonModule,
    FormsModule,
    FontAwesomeModule,
    MaterialModule
  ]
})
export class BooksModule { }
