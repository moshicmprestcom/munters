import {AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {BooksService} from '../../services/books.service';
import {IBook} from '../../models/book.model';
import {fromEvent, Observable, of, Subscription} from 'rxjs';
import {faTimes, faSearch} from '@fortawesome/free-solid-svg-icons';
import {debounceTime, delay, switchMap} from 'rxjs/operators';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.scss']
})
export class BookListComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('filter', {static: false}) filter: ElementRef;
  originBooksList: IBook[];
  booksList: IBook[];
  faTimes = faTimes;
  faSearch = faSearch;
  subscriptions = new Subscription();

  constructor(public service: BooksService) {
  }

  ngOnInit(): void {
    this.subscribeToBooks();
  }

  private subscribeToBooks(): void {
    this.subscriptions.add(this.service.booksListSubject.subscribe((list: IBook[]) => {
      this.originBooksList = list;
      this.booksList = [...this.originBooksList];
    }));
  }

  onSelected(book: IBook): void {
    this.service.bookSelected(book);
  }

  deleteBook(book: IBook): void {
    this.service.deleteBook(book);
  }

  ngAfterViewInit(): void {
    fromEvent(this.filter.nativeElement, 'keyup').pipe(debounceTime(500))
      .subscribe((res: any) => this.filterList(res.target.value));
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private filterList(value): void {
    this.booksList = this.originBooksList.filter((item: IBook) => {
      return item.bookName.toLocaleLowerCase().indexOf(value.toLocaleLowerCase()) > -1;
    });
  }
}
