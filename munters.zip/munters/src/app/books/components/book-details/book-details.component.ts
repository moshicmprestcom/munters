import {Component, OnDestroy, OnInit} from '@angular/core';
import {BooksService} from '../../services/books.service';
import {Subscription} from 'rxjs';
import {IBook} from '../../models/book.model';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.scss']
})
export class BookDetailsComponent implements OnInit, OnDestroy {

  book: IBook = {} as IBook;
  subscriptions = new Subscription();
  imgSrc = '';

  constructor(public service: BooksService) {
  }

  ngOnInit(): void {
    this.subscribeToSelectedBook();
  }

  onSubmitForm(): void {
    this.service.updateBook(this.book);
  }

  private subscribeToSelectedBook(): void {
    this.subscriptions.add(
      this.service.bookSubject
        .subscribe((selectedBook: IBook) => {
          this.book = selectedBook;
          this.imgSrc += `../../../../assets/images/${this.book.catalogNumber}.jpg`;
        })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
