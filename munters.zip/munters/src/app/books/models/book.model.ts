export interface IBook {
  catalogNumber: string;
  bookName: string;
  authorName: string;
  publicationDate: string;
}
