import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {IBook} from '../models/book.model';
import {Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BooksService {
  booksList: IBook[];
  selectedBook: IBook;

  booksListSubject = new Subject<IBook[]>();
  bookSubject = new Subject<IBook>();

  insertMode = false;

  constructor(private http: HttpClient) {
    this.initBooks();
  }

  private initBooks(): void {
    const url = '../../../assets/mock/books.json';
    this.http.get(url)
      .subscribe((response: IBook[]) => {
        this.booksList = response;
        this.emitBooks();
      });
  }

  private emitBooks(): void {
    this.insertMode = false;
    this.booksListSubject.next(this.booksList);
  }

  public deleteBook(book: IBook): void {
    this.booksList = this.booksList.filter((item: IBook) => {
      return item.catalogNumber !== book.catalogNumber;
    });
    if (this.selectedBook.catalogNumber === book.catalogNumber) {
      this.bookSelected({} as IBook);
    }
    this.emitBooks();
  }

  public updateBook(book: IBook): void {
    if (this.insertMode) {
      this.booksList.push(book);
    }
    this.emitBooks();
  }

  public bookSelected(book: IBook): void {
    this.selectedBook = book;
    this.bookSubject.next(this.selectedBook);
  }

  public createNewBook(): void {
    this.insertMode = true;
    this.bookSelected({} as IBook);
  }
}
